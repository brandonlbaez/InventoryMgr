package controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 The MainMenuController method has all functions associated with the MainMenu.fxml file.
 Initializable is implemented to allow for .fxml entities to be interacted with.*/
public class MainMenuController implements Initializable {
    @FXML
    private TableView<Part> displayParts;

    @FXML
    private TableView<Product> displayProducts;

    @FXML
    private TableColumn<Part, Integer> displayPartID;

    @FXML
    private TableColumn<Part, Integer> displayPartLevel;

    @FXML
    private TableColumn<Part, String> displayPartName;

    @FXML
    private TableColumn<Part, Double> displayPartPrice;

    @FXML
    private TableColumn<Product, Integer> displayProductID;

    @FXML
    private TableColumn<Product, Integer> displayProductLevel;

    @FXML
    private TableColumn<Product, String> displayProductName;

    @FXML
    private TableColumn<Product, Double> displayProductPrice;

    @FXML
    private TextField partsSearch;

    @FXML
    private TextField productsSearch;

    /**
     The addParts method will look for the AddPart.fxml file and launch it in a new window
     when the add part button is pressed in the MainMenuController.*/
    @FXML
    void addParts() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddPart.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    /**
     The addProducts method will look for the AddProduct.fxml file and launch it in a new window
     when the add product button is pressed in the MainMenuController.*/
    @FXML
    void addProduct() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddProduct.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    /**
     The deleteParts method will ask the user for confirmation before deleting the specified part.
     If there is no selected item, it will display a warning dialog telling the user to select a
     part before deleting it. */
    @FXML
    void deleteParts() {
        if (displayParts.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please select a part in order " +
                    "to delete it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Part selectedPart = displayParts.getSelectionModel().getSelectedItem();
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "This will delete the part you " +
                "selected. Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Inventory.deletePart(selectedPart);
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    /**
     The deleteProducts method will ask the user for confirmation before deleting the specified product.
     If there is no selected item, it will display a warning dialog telling the user to select a
     part before deleting it. It will also check to see if the chosen product has parts associated
     with it and will prompt the user to remove the chosen product's associated parts first before
     deleting the product.*/
    @FXML
    void deleteProduct() {
        if (displayProducts.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please select a product in order " +
                    "to delete it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Product selectedProduct = displayProducts.getSelectionModel().getSelectedItem();
        if (! selectedProduct.getAllAssociatedParts().isEmpty()) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "This product has parts associated with it. " +
                    "You must modify this part " +
                   "and delete all of its associated parts before deleting this product.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "This will delete the product you " +
                "selected. Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Inventory.deleteProduct(selectedProduct);
            }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    /**
     When the user clicks on the exit button, the exitProgram method asks the user
     for confirmation before exiting the application.*/
    @FXML
    void exitProgram() {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to exit the program?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Platform.exit();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    /**
     The modParts method will look for whether the specified part is either an InHouse or Outsourced
     part, and cast it to the passObject method. It will attempt to open the ModifyPart.fxml file and
     prompt the user to make sure a part is selected in the table if an exception occurs.*/
    @FXML
    void modParts() {
        TableView.TableViewSelectionModel<Part> selectedPart = displayParts.getSelectionModel();
        if (displayParts.getSelectionModel().getSelectedItem() instanceof InHouse) {
            ModifyPartController.passObject((InHouse) selectedPart.getSelectedItem());
        }
        else {
            ModifyPartController.passObject((Outsourced) selectedPart.getSelectedItem());
        }

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyPart.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setTitle("Modify Parts");
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please click on a part to modify it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
            }
        }
    }
    /**
     The modProducts method will take the product selected in the table and pass it to the passObject method.
     If the ModifyProduct.fxml file cannot be opened, it will prompt the user to make sure that a product
     is selected in the table.*/
    @FXML
    void modifyProduct() {
        TableView.TableViewSelectionModel<Product> selectedProduct = displayProducts.getSelectionModel();
        ModifyProductController.passObject(selectedProduct.getSelectedItem());

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyProduct.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setTitle("Modify Products");
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please click on a product to modify it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
            }
        }
    }

    /**
     The isNumeric function checks to see if a given string can be successfully parsed into
     an integer and will return false if it is unable to do so. It will return true if it is
     successful.
     @param name The string that is to be checked.
     @return Returns a true or false value. */
    public static boolean isNumeric(String name) {
        try {
            Integer.parseInt(name);
        }
        catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /**
     The searchPartHandler will use the isNumeric function to see if the string typed in the partsSearch
     text field can be parsed as an integer. If isNumeric returns a true value, it will create a new
     ObservableList called desiredID, call the lookupPart method for that specific integer, and will set the
     items in the table to show a part matching the ID typed in the text field. If isNumeric returns a false
     value, it will call the lookupPart method for the given string, and have the table show all products
     containing the string typed in the text field. The method will also prompt the user if a matching
     ID or name was not found, and will reset the partsSearch text field and displayParts table view.*/
    public void searchPartHandler() {
        if (MainMenuController.isNumeric(partsSearch.getText())) {
            ObservableList<Part> desiredID = FXCollections.observableArrayList();
            Part searchPart = Inventory.lookupPart(Integer.parseInt(partsSearch.getText()));
            desiredID.add(searchPart);
            if (desiredID.contains(null)) {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "A matching ID or name was not found.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    displayParts.setItems(Inventory.getAllParts());
                    partsSearch.clear();
                }
            }
            else {
                displayParts.setItems(desiredID);
            }
        }
        else if (!MainMenuController.isNumeric(partsSearch.getText())) {
            if (!Inventory.lookupPart(partsSearch.getText()).isEmpty()) {
                displayParts.setItems(Inventory.lookupPart(partsSearch.getText()));
            }
            else {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                    "A matching ID or name was not found.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                displayParts.setItems(Inventory.getAllParts());
                partsSearch.clear();
                }
            }
        }
    }

    /**
     The searchProductHandler will use the isNumeric function to see if the string typed in the
     productsSearch text field can be parsed as an integer. If isNumeric returns a true value, it will create a new
     ObservableList called desiredID, call the lookupProduct method for that specific integer, and will set the
     items in the table to show a product matching the ID typed in the text field. If isNumeric returns a false
     value, it will call the lookupProduct method for the given string, and have the table show all products
     containing the string typed in the text field. The method will also prompt the user if a matching
     ID or name was not found, and will reset the productsSearch text field and displayProducts table view.*/
    public void searchProductHandler() {
        if (MainMenuController.isNumeric(productsSearch.getText())) {
            ObservableList<Product> desiredID = FXCollections.observableArrayList();
            Product searchProduct = Inventory.lookupProduct(Integer.parseInt(productsSearch.getText()));
            desiredID.add(searchProduct);
            if (desiredID.contains(null)) {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "A matching ID or name was not found.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    displayProducts.setItems(Inventory.getAllProducts());
                    productsSearch.clear();
                }
            }
            else {
                displayProducts.setItems(desiredID);
            }
        }
        else if (!MainMenuController.isNumeric(productsSearch.getText())) {
            if (!Inventory.lookupProduct(productsSearch.getText()).isEmpty()) {
                displayProducts.setItems(Inventory.lookupProduct(productsSearch.getText()));
            }
            else {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "A matching ID or name was not found.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    displayProducts.setItems(Inventory.getAllProducts());
                    productsSearch.clear();
                }
            }
        }
    }

    /**
     The initialize method will set the tables to display all parts and products, and set the cells
     in the table to display a part or product's ID, name, stock and price, respectively.
     @param url The location of the .fxml file.
     @param resourceBundle Resources used that pertain to the user's locale. */
    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        displayParts.setItems(Inventory.getAllParts());
        displayProducts.setItems(Inventory.getAllProducts());

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayProductID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayProductName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayProductLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayProductPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}