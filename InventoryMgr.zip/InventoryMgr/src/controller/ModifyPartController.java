package controller;

import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
public class ModifyPartController implements Initializable {

    private static Part selectedPart;

    @FXML
    private RadioButton modifyInHouse;

    @FXML
    private RadioButton modifyOutsourced;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyID;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private Button Save;

    @FXML
    private TextField modifyDynTxtField;

    @FXML
    private ToggleGroup toggleGroup1;

    @FXML
    private Label dynamicTextField;

    @FXML
    void SelectPart(ActionEvent event) {

    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) {

    }


    static void passObject(InHouse part){
        selectedPart = part;
    }

    static void passObject(Outsourced part){
        selectedPart = part;
    }

    @FXML
    void cancel(ActionEvent event) {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to cancel?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) Cancel.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    @FXML
    void modifyID(ActionEvent event) {

    }

    @FXML
    void modifyInv(ActionEvent event) {

    }

    @FXML
    void modifyMachineID(ActionEvent event) {

    }

    @FXML
    void modifyMax(ActionEvent event) {

    }

    @FXML
    void modifyMin(ActionEvent event) {

    }

    @FXML
    void modifyName(ActionEvent event) {

    }

    @FXML
    void modifyPrice(ActionEvent event) {

    }

    @FXML
    void save() {
        String validStock = modifyInv.getText();
        String validMin = modifyMin.getText();
        String validMax = modifyMax.getText();
        String validName = modifyName.getText();
        String validPrice = modifyPrice.getText();
        String validDynamicTxtField = modifyDynTxtField.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank() ||
                validDynamicTxtField.isBlank()
        )
        {
            Alert alert = new Alert((Alert.AlertType.WARNING), "At least one of your text fields is blank.\n" +
                    "Please make sure all text fields have a valid value.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(modifyInv.getText());
            error = "Min";
            int min = Integer.parseInt(modifyMin.getText());
            error = "Max";
            int max = Integer.parseInt(modifyMax.getText());
            error = "Name";
            String name = modifyName.getText();
            error = "Price";
            double price = Double.parseDouble(modifyPrice.getText());

            if (min > stock || stock > max) {
                Alert alert = new Alert((Alert.AlertType.WARNING), "Min must be less than or equal to " +
                        "stock.\nThe stock must be less than or equal to the max.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    return;
                }
            }

            if (selectedPart instanceof InHouse) {
                int machineID = Integer.parseInt(modifyDynTxtField.getText());
                Inventory.updatePart(selectedPart.getId(),
                        new InHouse(selectedPart.getId(), name, price, stock, min, max, machineID));
            }
            else {
                String companyName = modifyDynTxtField.getText();
                Inventory.updatePart(selectedPart.getId(),
                        new Outsourced(selectedPart.getId(), name, price, stock, min, max, companyName));
            }
        }
        catch (IllegalArgumentException e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), error + " is an invalid value.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        Stage stage = (Stage) Save.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modifyID.setText(String.valueOf(selectedPart.getId()));
        modifyInv.setText(String.valueOf(selectedPart.getStock()));
        modifyName.setText(selectedPart.getName());
        modifyPrice.setText(String.valueOf(selectedPart.getPrice()));
        modifyMin.setText(String.valueOf(selectedPart.getMin()));
        modifyMax.setText(String.valueOf(selectedPart.getMax()));
        if (selectedPart instanceof InHouse) {
            dynamicTextField.setText("Machine ID");
            modifyDynTxtField.setText(String.valueOf(((InHouse) selectedPart).getMachineID()));
            modifyOutsourced.setDisable(true);
        }
        else {
            dynamicTextField.setText("Company Name");
            modifyOutsourced.setSelected(true);
            modifyInHouse.setSelected(false);
            modifyInHouse.setDisable(true);
            modifyDynTxtField.setText(((Outsourced) selectedPart).getCompanyName());
        }
    }
}
