package controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

/**
 The ModifyPartController method has all functions associated with the ModifyPart.fxml file.
 Initializable is implemented to allow for .fxml entities to be interacted with.*/
public class ModifyPartController implements Initializable {

    /**
     The private static selectedPart is used whenever a part needs to be modified or
     transferred to another controller for use elsewhere in the program.*/
    private static Part selectedPart;

    @FXML
    private RadioButton modifyInHouse;

    @FXML
    private RadioButton modifyOutsourced;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyID;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private Button Save;

    @FXML
    private TextField modifyDynTxtField;

    @FXML
    private Label dynamicTextField;

    /**
     The selectInHousePart method will change the dynamicTextField's text to Machine ID and
     unselect the modifyOutsourcedPart radio button when the modifyInHouse radio button is selected.*/
    @FXML
    void selectInHousePart() {
        dynamicTextField.setText("Machine ID");
        modifyOutsourced.setSelected(false);
    }

    /**
     The selectOutsourcedPart method will change the dynamicTextField's text to Company Name and
     unselect the modifyInHouse radio button when the modifyOutsourced radio button is selected.*/
    @FXML
    void selectOutsourcedPart() {
        dynamicTextField.setText("Company Name");
        modifyInHouse.setSelected(false);
    }

    /**
     The passObject function uses the static selectedPart variable to pass the InHouse part selected
     on the MainMenuController to the ModifyPartController, so it can be modified.*/
    static void passObject(InHouse part){
        selectedPart = part;
    }

    /**
     The passObject function uses the static selectedPart variable to pass the Outsourced part selected
     on the MainMenuController to the ModifyPartController, so it can be modified.*/
    static void passObject(Outsourced part){
        selectedPart = part;
    }

    /**
     The cancel function asks the user if they are sure they want to stop modifying the selected
     part. It will close the ModifyPart.fxml file if OK is selected and close the alert window
     if cancel is selected.*/
    @FXML
    void cancel() {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to cancel?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) Cancel.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }
    /**
     The save method will check to see if any of the text fields are blank and prompt the user
     to make sure all text fields have a value before pressing save. The method will then
     try to parse the values in the text fields. If the min is not less than or equal to
     the available stock, or the available stock is not less than or equal to the max,
     it will prompt the user to make sure this rule is followed. If any of the text fields have
     an incorrect value, the user will be prompted to make sure that name contains a string
     value and that stock, min, max, and price contain a numeric value. If no exceptions occur,
     the part will be updated to include the information that the user entered, but keep the same
     randomly generated ID that the part had before it was updated.*/
    @FXML
    void save() {
        String validStock = modifyInv.getText();
        String validMin = modifyMin.getText();
        String validMax = modifyMax.getText();
        String validName = modifyName.getText();
        String validPrice = modifyPrice.getText();
        String validDynamicTxtField = modifyDynTxtField.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank() ||
                validDynamicTxtField.isBlank())

        {
            Alert alert = new Alert((Alert.AlertType.WARNING), "At least one of your text fields is blank.\n" +
                    "Please make sure all text fields have a valid value.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        String error = "";
        try {

            error = "Stock";
            int stock = Integer.parseInt(modifyInv.getText());
            error = "Min";
            int min = Integer.parseInt(modifyMin.getText());
            error = "Max";
            int max = Integer.parseInt(modifyMax.getText());
            error = "Name";
            String name = modifyName.getText();
            error = "Price";
            double price = Double.parseDouble(modifyPrice.getText());

            if (min > stock || stock > max) {
                Alert alert = new Alert((Alert.AlertType.WARNING), "Min must be less than or equal to " +
                        "stock.\nThe stock must be less than or equal to the max.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    return;
                }
            }

            if (selectedPart instanceof Outsourced) {
                if (modifyInHouse.isSelected()) {
                    if (MainMenuController.isNumeric(modifyDynTxtField.getText())) {
                        int machineID = Integer.parseInt(modifyDynTxtField.getText());
                        Inventory.updatePart(selectedPart.getId(),
                            new InHouse(selectedPart.getId(), name, price, stock, min, max, machineID));
                    }
                    else {
                        Alert alert = new Alert((Alert.AlertType.WARNING),
                            "When changing an outsourced part to an in-house part, \n" +
                                    "the company name must be a string.");
                        Optional<ButtonType> result = alert.showAndWait();
                        if (result.isPresent() && result.get() == ButtonType.OK) {
                            alert.close();
                            return;
                        }
                else {
                    String companyName = modifyDynTxtField.getText();
                    Inventory.updatePart(selectedPart.getId(),
                        new Outsourced(selectedPart.getId(), name, price, stock, min, max, companyName));
                    return;
                        }
                    }
                }
            }

            if (selectedPart instanceof InHouse) {
                if (modifyOutsourced.isSelected()) {
                    if (!modifyDynTxtField.getText().matches("[0-9]")) {
                        String companyName = modifyDynTxtField.getText();
                        Inventory.updatePart(selectedPart.getId(),
                            new Outsourced(selectedPart.getId(), name, price, stock, min, max, companyName));
                    }
                    else {
                        Alert alert = new Alert((Alert.AlertType.WARNING),
                            "When changing an in-house part to an outsourced part, \n" +
                                    "the company name must be a string.");
                        Optional<ButtonType> result = alert.showAndWait();
                        if (result.isPresent() && result.get() == ButtonType.OK) {
                            alert.close();
                            return;
                        }
                    }
                }
                else {
                    int machineID = Integer.parseInt(modifyDynTxtField.getText());
                    Inventory.updatePart(selectedPart.getId(),
                        new InHouse(selectedPart.getId(), name, price, stock, min, max, machineID));
                    //return;
                }
            }
        }

        catch (IllegalArgumentException e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), error + " is an invalid value.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Stage stage = (Stage) Save.getScene().getWindow();
        stage.close();
    }

    /**
     The initialize function will set the text fields in the ModifyPart.fxml file
     to include the selectedPart's ID, stock, name, price, min and max values. It will
     change the modifyDynTxtField to say Machine ID and display the selectedPart's machineID if
     the selectedPart is an InHouse part. If the selectedPart is an Outsourced part, it will
     display the selectedPart's companyName and change the modifyDynTxtField to say Company
     Name. It will also prevent the user from changing the selectedPart to an Outsourced
     part if it is an InHouse part, and vice versa.
     @param url The location of the .fxml file.
     @param resourceBundle Resources used that pertain to the user's locale.*/
    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modifyID.setText(String.valueOf(selectedPart.getId()));
        modifyInv.setText(String.valueOf(selectedPart.getStock()));
        modifyName.setText(selectedPart.getName());
        modifyPrice.setText(String.valueOf(selectedPart.getPrice()));
        modifyMin.setText(String.valueOf(selectedPart.getMin()));
        modifyMax.setText(String.valueOf(selectedPart.getMax()));
        if (selectedPart instanceof InHouse) {
            dynamicTextField.setText("Machine ID");
            modifyDynTxtField.setText(String.valueOf(((InHouse) selectedPart).getMachineID()));
            modifyInHouse.setSelected(true);
            modifyOutsourced.setSelected(false);
        }
        else {
            dynamicTextField.setText("Company Name");
            modifyOutsourced.setSelected(true);
            modifyInHouse.setSelected(false);
            modifyDynTxtField.setText(((Outsourced) selectedPart).getCompanyName());
        }
    }
}