package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Brandon
 */
public class Inventory {
    private static ObservableList<Parts> allParts = FXCollections.observableArrayList();
    private static ObservableList<Parts> filterParts = FXCollections.observableArrayList();

    private static ObservableList<Products> allProducts = FXCollections.observableArrayList();

    private static ObservableList<Products> filterProducts = FXCollections.observableArrayList();

    public static void addParts(Parts parts) {
        allParts.add(parts);
    }

    public static void addProducts(Products products) {
        allProducts.add(products);
    }

    public static ObservableList<Parts> getAllParts() {
            return allParts;
    }

    public static ObservableList<Parts> getFilteredParts() {
        return filterParts;
    }

    public static ObservableList<Products> getAllProducts() {
        return allProducts;
    }

    public static ObservableList<Products> getFilteredProducts() {
        return filterProducts;
    }
}
