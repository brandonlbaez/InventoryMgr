package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;

import java.io.IOException;

public class AddInHouseController {

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;

    @FXML
    private TextField addID;

    @FXML
    private TextField addInv;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private Button save;

    @FXML
    private TextField addMachineID;

    @FXML
    void SelectInHousePart(ActionEvent event) {
        ;
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/AddOutsourced.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void addID(ActionEvent event) {

    }

    @FXML
    void addInv(ActionEvent event) {

    }

    @FXML
    void addMachineID(ActionEvent event) {

    }

    @FXML
    void addMax(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) throws IOException {
        int id = Integer.parseInt(addID.getText());
        int stock = Integer.parseInt(addInv.getText());
        int min = Integer.parseInt(addMin.getText());
        int max = Integer.parseInt(addMax.getText());
        String name = addName.getText();
        double price = Double.parseDouble(addPrice.getText());
        int machineID = Integer.parseInt(addMachineID.getText());

        Inventory.addParts(new InHouse(id, name, price, stock, min, max, machineID));

        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }

}
