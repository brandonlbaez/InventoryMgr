package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

/**
 The AddPartController method has all functions associated with the AddPart.fxml file.
 Initializable is implemented to allow for .fxml entities to be interacted with.*/
public class AddPartController {

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;
    @FXML
    private Label dynamicLabel;

    @FXML
    private TextField addStock;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private Button save;

    @FXML
    private TextField dynamicTextField;

    /**
     The selectInHousePart method will change the dynamicLabel's text to Machine ID and
     unselect the AddOutsourcedPart radio button when the AddInHouse radio button is selected.*/
    @FXML
    void selectInHousePart() {
        dynamicLabel.setText("Machine ID");
        AddOutsourcedPart.setSelected(false);
    }

    /**
     The selectOutsourcedPart method will change the dynamicLabel's text to Company Name and
     unselect the AddInHousePart radio button when the AddOutsourced radio button is selected.*/
    @FXML
    void selectOutsourcedPart() {
        dynamicLabel.setText("Company Name");
        AddInHouse.setSelected(false);
    }

    /**
     The cancel method will ask the user if they are sure they want to cancel adding a new part by calling the
     confirmClose method. If the user selects OK, it will close the AddPart.fxml file. Selecting cancel will
     close the alert window.*/
    @FXML
    void cancel() {
        Dialog.confirmClose(Cancel);
    }

    /**
     The save method will check to see if any of the text fields are blank and prompt the user
     to make sure all text fields have a value before pressing save by calling the resetScreen method.
     The method will then try to parse the values in the text fields. If the min is not less than or equal to
     the available stock, or the available stock is not less than or equal to the max,
     it will prompt the user to make sure this rule is followed. If any of the text fields have
     an incorrect value, the user will be prompted to make sure that name contains a string
     value and that stock, min, max, and price contain a numeric value. If no exceptions occur,
     the program will create either an InHouse or Outsourced part depending on which radio
     button the user selected, then close the AddPart.fxml window.*/
    @FXML
    void save() {
        String validStock = addStock.getText();
        String validMin = addMin.getText();
        String validMax = addMax.getText();
        String validName = addName.getText();
        String validPrice = addPrice.getText();
        String validDynamicTxtField = dynamicTextField.getText();

        if (String.valueOf(validStock).isBlank() || String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() || validName.isBlank() ||
                String.valueOf(validPrice).isBlank() || validDynamicTxtField.isBlank()) {
            Dialog.resetScreen("At least one of your text fields is blank. \n" +
                    "Please make sure all text fields have a value before pressing save.");
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(addStock.getText());
            error = "Min";
            int min = Integer.parseInt(addMin.getText());
            error = "Max";
            int max = Integer.parseInt(addMax.getText());
            error = "Name";
            String name = addName.getText();
            error = "Price";
            double price = Double.parseDouble(addPrice.getText());

            if (min > stock || stock > max) {
                Dialog.resetScreen(
                        "Error: Min must be less than or equal to the available stock.\n" +
                                "The available stock must be less than or equal to the max.");
                return;
            }
            if (AddInHouse.isSelected()) {
                int machineID = Integer.parseInt(dynamicTextField.getText());
                Inventory.addPart(new InHouse(Inventory.partRandomId(), name, price, stock, min, max, machineID));
            }
            else {
                String companyName = dynamicTextField.getText();
                Inventory.addPart(new Outsourced(Inventory.partRandomId(), name, price, stock, min, max, companyName));
            }
        }
        catch (IllegalArgumentException e) {
            Dialog.resetScreen( error + " is an incorrect value. " +
                    "Stock, min, max and price must contain a number. " +
                    "Name must contain a sequence of letters and/or numbers.");
            return;
        }
        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }
}