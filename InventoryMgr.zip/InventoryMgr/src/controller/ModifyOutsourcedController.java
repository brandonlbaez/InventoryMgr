package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

import java.io.IOException;

public class ModifyOutsourcedController {

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;

    @FXML
    private TextField DisplayID;

    @FXML
    private TextField DisplayInv;

    @FXML
    private TextField DisplayMax;

    @FXML
    private TextField DisplayMin;

    @FXML
    private TextField DisplayName;

    @FXML
    private TextField DisplayPrice;

    @FXML
    private Button Save;

    @FXML
    private TextField displayMachineID;

    @FXML
    private ToggleGroup toggleGroup1;

    @FXML
    void SelectInHousePart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/ModifyInHouse.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) throws IOException {
        ;
    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void displayID(ActionEvent event) {

    }

    @FXML
    void displayInv(ActionEvent event) {

    }

    @FXML
    void displayMachineID(ActionEvent event) {

    }

    @FXML
    void displayMax(ActionEvent event) {

    }

    @FXML
    void displayMin(ActionEvent event) {

    }

    @FXML
    void displayName(ActionEvent event) {

    }

    @FXML
    void displayPrice(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) {

    }

}
