package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.Random;

public class Product {

    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private int id, stock, max, min;
    private String name;
    private double price;

    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.setName(name);
        this.setPrice(price);
        this.setStock(stock);
        this.setMin(min);
        this.setMax(max);
    }

    public static int randomId() {
        Random random = new Random();
        int lowerBound = 1000000;
        int upperBound = 9999999;
        return random.nextInt(lowerBound, upperBound);
    }
    public void addAssociatedPart(Part parts) {
        associatedParts.add(parts);
    }

    public boolean deleteAssociatedPart(Part associatedPart) {
        for (Product products : Inventory.getAllProducts()) {
            if (products.getAllAssociatedParts().contains(associatedPart))
                return products.getAllAssociatedParts().remove(associatedPart);
        }
        return false;
    }

    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
