package controller;

import javafx.fxml.Initializable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Parts;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
public class ModifyInHouseController implements Initializable {

    private static Parts selectedPart;

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyID;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private Button Save;

    @FXML
    private TextField modifyMachineID;

    @FXML
    private ToggleGroup toggleGroup1;

    @FXML
    void SelectInHousePart(ActionEvent event) {
        ;
    }

    static Parts passObject(Parts part){
        selectedPart = part;
        System.out.println(part);
        return part;
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/ModifyOutsourced.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void modifyID(ActionEvent event) {

    }

    @FXML
    void modifyInv(ActionEvent event) {

    }

    @FXML
    void modifyMachineID(ActionEvent event) {

    }

    @FXML
    void modifyMax(ActionEvent event) {

    }

    @FXML
    void modifyMin(ActionEvent event) {

    }

    @FXML
    void modifyName(ActionEvent event) {

    }

    @FXML
    void modifyPrice(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) {
        int id = Integer.parseInt(modifyID.getText());
        int stock = Integer.parseInt(modifyMachineID.getText());
        int min = Integer.parseInt(modifyMin.getText());
        int max = Integer.parseInt(modifyMax.getText());
        String name = modifyName.getText();
        double price = Double.parseDouble(modifyPrice.getText());
        int machineID = Integer.parseInt(modifyMachineID.getText());

        Inventory.addParts(new InHouse(id, name, price, stock, min, max, machineID));

        Stage stage = (Stage) Save.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modifyID.setText(String.valueOf(selectedPart.getId()));
        modifyInv.setText(String.valueOf(selectedPart.getStock()));
        modifyName.setText(selectedPart.getName());
        modifyPrice.setText(String.valueOf(selectedPart.getPrice()));
        modifyMin.setText(String.valueOf(selectedPart.getMin()));
        modifyMax.setText(String.valueOf(selectedPart.getMax()));
    }
}
