package controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Parts;

import java.io.IOException;
public class MainMenu extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/MainMenu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Inventory Manager");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        InHouse examplePart = new InHouse(204042, "Transistor", 0.02, 5, 0, 100000, 68868);
        InHouse examplePart2 = new InHouse(204662, "Bolt", 0.01, 5000, 0, 10000, 68898);
        InHouse examplePart3 = new InHouse(206042, "Wrench", 8.00, 10, 0, 100, 86808);
        Outsourced examplePart4 = new Outsourced(264042, "Table", 150.00, 2, 0, 10, "HP");
        Outsourced examplePart5 = new Outsourced(604042, "Hard Drive", 100.00, 50, 0, 1000, "Lenovo");
        Inventory.addParts(examplePart);
        Inventory.addParts(examplePart2);
        Inventory.addParts(examplePart3);
        Inventory.addParts(examplePart4);
        Inventory.addParts(examplePart5);
        launch();
    }
}


