package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 The AddProductController method has all functions associated with the AddProduct.fxml file.
 Initializable is implemented to allow for .fxml entities to be interacted with.*/
public class AddProductController implements Initializable {

    /**
     This static final chosenAssocParts variable stores an ObservableList of parts
     that will be added to a newly created product.*/
    private static final ObservableList<Part> chosenAssocParts = FXCollections.observableArrayList();

    @FXML
    private TextField partsSearch;

    @FXML
    private Button Cancel;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addStock;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private TableView<Part> displayAllParts;

    @FXML
    private TableView<Part> displayAssociatedParts;

    @FXML
    private TableColumn<Part, Integer> displayPartID;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartID;

    @FXML
    private TableColumn<Part, Integer> displayPartLevel;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartLevel;

    @FXML
    private TableColumn<Part, String> displayPartName;

    @FXML
    private TableColumn<Part, String> displayAssocPartName;

    @FXML
    private TableColumn<Part, Double> displayPartPrice;

    @FXML
    private TableColumn<Part, Double> displayAssocPartPrice;
    @FXML
    private Button save;

    /**
     The partsSearch method will use the isNumeric function to see if the string typed in the
     partsSearch text field can be parsed as an integer. If isNumeric returns a true value, it will create a new
     ObservableList called desiredID, call the lookupPart method for that specific integer, and will set the
     items in the table to show a part matching the ID typed in the text field. If isNumeric returns a false
     value, it will call the lookupPart method for the given string, and have the table show all parts
     containing the string typed in the text field. The method will also prompt the user if a matching
     ID or name was not found, and will reset the partsSearch text field and displayAllParts table view.*/
    @FXML
    void partsSearch() {
        if (MainMenuController.isNumeric(partsSearch.getText())) {
            ObservableList<Part> desiredID = FXCollections.observableArrayList();
            desiredID.add(Inventory.lookupPart(Integer.parseInt(partsSearch.getText())));
            if (Inventory.lookupPart(Integer.parseInt(partsSearch.getText())) != null) {
                displayAllParts.setItems(desiredID);
            }
            else {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "A matching ID or name was not found.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    displayAllParts.setItems(Inventory.getAllParts());
                    partsSearch.clear();
                }
            }
        }
        else {
            displayAllParts.setItems(Inventory.lookupPart(partsSearch.getText()));
        }
    }

    /**
     The Cancel method will ask the user whether they want to stop adding a product to the
     inventory. If OK is selected, the window will close. If cancel is selected, the dialog will
     close and the user can proceed normally.*/
    @FXML
    void Cancel() {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to cancel?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) Cancel.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    /**
     The addAssocPart method will take the selected item in the displayAllParts table and
     add it to the static ObservableList named chosenAssocParts. The displayAssociatedParts
     table will set the items in the table to display any products that are in the chosenAssocParts
     ObservableList. It will not let the user associate duplicate parts to a product.*/
    @FXML
    void addAssocPart() {
        Part selectedPart = displayAllParts.getSelectionModel().getSelectedItem();
        if (chosenAssocParts.contains(selectedPart)) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    "This part is already associated with the \nproduct you are creating.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        chosenAssocParts.add(selectedPart);
        displayAssociatedParts.setItems(chosenAssocParts);
    }

    /**
     The removeAssocPart method will take the selected item in the displayAllParts table and
     remove it from the static ObservableList named chosenAssocParts. The displayAssociatedParts
     table will set the items in the table to display any products that are in the chosenAssocParts
     ObservableList, which will no longer include the removed associated part.*/
    @FXML
    void removeAssocPart() {
        if (displayAssociatedParts.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    "A part must be selected in order to remove it from this table.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Part selectedPart = displayAssociatedParts.getSelectionModel().getSelectedItem();
        chosenAssocParts.remove(selectedPart);
        displayAssociatedParts.setItems(chosenAssocParts);
    }

    /**
     The save method will check to see if any of the text fields are blank and prompt the user
     to make sure all text fields have a value before pressing save. The method will then
     try to parse the values in the text fields. If the min is not less than or equal to
     the available stock, or the available stock is not less than or equal to the max,
     it will prompt the user to make sure this rule is followed. If any of the text fields have
     an incorrect value, the user will be prompted to make sure that name contains a string
     value and that stock, min, max, and price contain a numeric value. If no exceptions occur,
     the program will create a new product, add any associated parts located in the
     displayAssociatedParts table, and then close the AddProduct.fxml window.<br><br>

     <b>LOGICAL ERROR:</b> A logical error that I encountered while creating this application was associating
     parts to newly created products. Instead of the program associating parts with a
     product as intended, the program would either remove the part from memory
     altogether, or simply fail to associate the parts with the newly created product. In order
     to fix this, I needed to not use the remove method (for the former case), and create a static
     ObservableList (called chosenAssocParts) that the program loops through instead.
     Realizing that all new objects would, in effect, be placed at the last index of
     chosenAssocParts, I decided to access the last index of the ObservableList after creating
     the new product, loop through chosenAssocParts and associate each part with the newly
     created product.*/
    @FXML
    void save() {
        String validStock = addStock.getText();
        String validMin = addMin.getText();
        String validMax = addMax.getText();
        String validName = addName.getText();
        String validPrice = addPrice.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank()) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    "At least one of your text fields is blank. \n" +
                    "Please make sure all text fields have a value before pressing save.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(addStock.getText());
            error = "Min";
            int min = Integer.parseInt(addMin.getText());
            error = "Max";
            int max = Integer.parseInt(addMax.getText());
            error = "Name";
            String name = addName.getText();
            error = "Price";
            double price = Double.parseDouble(addPrice.getText());

            if (min > stock || stock > max) {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "Error: Min must be less than or equal to the available stock.\n" +
                        "The available stock must be less than or equal to the max.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    return;
                }
            }
            Product newProduct = new Product(Inventory.productRandomId(), name, price, stock, min, max);
            newProduct.getAllAssociatedParts().addAll(chosenAssocParts);
            Inventory.addProduct(newProduct);
        }
        catch (IllegalArgumentException e) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    error + " is an incorrect value. " +
                    "Stock, min, max and price must contain a number. " +
                    "Name must contain a sequence of letters and/or numbers.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }

    /**
     The initialize method will set the displayAllParts table to display all parts, and set the cells
     in the table to display a part's ID, name, stock and price. It will also set up the cells in the
     displayAssociatedParts table to display the same parameters as the displayAllParts table, but will
     not set up any parts to be displayed as that depends on the parts that are contained in the
     chosenAssocParts ObservableList.
     @param url The location of the .fxml file.
     @param resourceBundle Resources used that pertain to the user's locale.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        displayAllParts.setItems(Inventory.getAllParts());

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayAssocPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayAssocPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayAssocPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayAssocPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}
