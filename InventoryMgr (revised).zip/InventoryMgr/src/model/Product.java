package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 The Product class is similar to the Part class, but is not abstract and also contains an
 ObservableList of parts that are associated with this product.*/
public class Product {

    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    private int id, stock, max, min;
    private String name;
    private double price;

    /**
     The Product constructor creates a new product when called, and initializes the new product
     with the values given in the parameters of the constructor.
     @param id The ID of the product.
     @param name The name of the product.
     @param price The price of the product.
     @param stock The stock of the product.
     @param min The lowest possible amount of a product.
     @param max The highest possible amount of a product.*/
    public Product(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.setName(name);
        this.setPrice(price);
        this.setStock(stock);
        this.setMin(min);
        this.setMax(max);
    }

    /**
     The addAssociatedPart method adds a part to the ObservableList
     of associatedParts for the given product.
     @param part The part to be added to the ObservableList of associatedParts.*/
    public void addAssociatedPart(Part part) {
        associatedParts.add(part);
    }

    /**
     The removeAssociatedPart method removes a part from the ObservableList
     of associatedParts for the given product.
     @param selectedAssociatedPart The part to be added to the ObservableList of associatedParts.
     @return Returns false if the part is not in the ObservableList of associatedParts.*/
    public boolean deleteAssociatedPart(Part selectedAssociatedPart) {
        for (Product products : Inventory.getAllProducts()) {
            if (products.getAllAssociatedParts().contains(selectedAssociatedPart)) {
                return products.getAllAssociatedParts().remove(selectedAssociatedPart);
            }
        }
        return false;
    }

    /**
     The getAllAssociatedParts method returns the product's ObservableList of associatedParts.
     @return Returns an ObservableList of all associatedParts of a product.*/
    public ObservableList<Part> getAllAssociatedParts() {
        return associatedParts;
    }


    /**
     The getId method returns the ID associated with a product.
     @return Returns the ID of a product.*/
    public int getId() {
        return id;
    }

    /**
     The setId method sets the ID of a product to the integer given in the parameter.
     @param id The ID the product will have after the method is called.*/
    public void setId(int id) {
        this.id = id;
    }

    /**
     The getStock method returns the available amount of a product.
     @return Returns the available amount of a product.*/
    public int getStock() {
        return stock;
    }

    /**
     The setStock method sets the available amount of a product to the integer given in the parameter.
     @param stock The available amount of the product after the method is called.*/
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     The getMin method returns the minimum amount of a product that can be in
     the inventory.
     @return Returns the minimum allowed amount of a product.*/
    public int getMin() {
        return min;
    }

    /**
     The setMin method sets the lowest possible amount of a product
     that can be in the inventory to the integer given in the parameter.
     @param min The lowest possible amount of the product allowed in the inventory.*/
    public void setMin(int min) {
        this.min = min;
    }

    /**
     The getMax method returns the maximum amount of a product that can be in
     the inventory.
     @return Returns the maximum allowed amount of a product.*/
    public int getMax() {
        return max;
    }

    /**
     The setMax method sets the highest possible amount of a product
     that can be in the inventory to the integer given in the parameter.
     @param max The highest possible amount of the product allowed in the inventory.*/
    public void setMax(int max) {
        this.max = max;
    }

    /**
     The getName method returns the name of a product.
     @return Returns the name of a product.*/
    public String getName() {
        return name;
    }

    /**
     The setName method changes the name of a product to the string given in the parameter.
     @param name The new name of the product.*/
    public void setName(String name) {
        this.name = name;
    }

    /**
     The getPrice method returns the price of a product.
     @return Returns the price of a product.*/
    public double getPrice() {
        return price;
    }

    /**
     The setPrice method changes the price of a product to the double given in the parameter.
     @param price The new price of the product.*/
    public void setPrice(double price) {
        this.price = price;
    }
}