package model;

/**
 *
 * @author Brandon
 */
public class Inventory {

}
