package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

import java.util.Optional;

public class AddPartController {

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;
    @FXML
    private Label dynamicLabel;

    @FXML
    private TextField addStock;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private Button save;

    @FXML
    private TextField dynamicTextField;

    @FXML
    void SelectInHousePart(ActionEvent event) {
        dynamicLabel.setText("Machine ID");
        AddOutsourcedPart.setSelected(false);
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) {
        dynamicLabel.setText("Company Name");
        AddInHouse.setSelected(false);
    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void addID(ActionEvent event) {

    }

    @FXML
    void addInv(ActionEvent event) {

    }

    @FXML
    void dynamicTextField(ActionEvent event) {

    }

    @FXML
    void addMax(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) {
        String validStock = addStock.getText();
        String validMin = addMin.getText();
        String validMax = addMax.getText();
        String validName = addName.getText();
        String validPrice = addPrice.getText();
        String validDynamicTxtField = dynamicTextField.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank() ||
                validDynamicTxtField.isBlank()) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "At least one of your text fields is blank. \n" +
                    "Please make sure all text fields have a value before pressing save.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(addStock.getText());
            error = "Min";
            int min = Integer.parseInt(addMin.getText());
            error = "Max";
            int max = Integer.parseInt(addMax.getText());
            error = "Name";
            String name = addName.getText();
            error = "Price";
            double price = Double.parseDouble(addPrice.getText());

            if (min > stock || stock > max) {
                Alert alert = new Alert((Alert.AlertType.WARNING), "Error: Min must be less than or equal to the " +
                        "available stock.\n" +
                        "The available stock must be less than or equal to the max.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    return;
                }
            }

            if (AddInHouse.isSelected()) {
                int machineID = Integer.parseInt(dynamicTextField.getText());
                Inventory.addParts(new InHouse(Inventory.partRandomId(), name, price, stock, min, max, machineID));
            }
            else {
                String companyName = dynamicTextField.getText();
                Inventory.addParts(new Outsourced(Inventory.partRandomId(), name, price, stock, min, max, companyName));
            }
        }
        catch (IllegalArgumentException e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), error + " is an incorrect value. " +
                    "Stock, min, max and price must contain a number. " +
                    "Name must contain a sequence of letters and/or numbers.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }
}
