package controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

public class MainMenuController implements Initializable {

    @FXML
    private Button addPartsButton;

    @FXML
    private Button addProduct;

    @FXML
    private Button deleteParts;

    @FXML
    private Button deleteProduct;

    @FXML
    private TableView<Part> tableView;

    @FXML
    private TableView<Product> tableViewProducts;

    @FXML
    private TableColumn<Part, Integer> displayPartID;

    @FXML
    private TableColumn<Part, Integer> displayPartLevel;

    @FXML
    private TableColumn<Part, String> displayPartName;

    @FXML
    private TableColumn<Part, Double> displayPartPrice;

    @FXML
    private TableColumn<Product, Integer> displayProductID;

    @FXML
    private TableColumn<Product, Integer> displayProductLevel;

    @FXML
    private TableColumn<Product, String> displayProductName;

    @FXML
    private TableColumn<Product, Double> displayProductPrice;

    @FXML
    private Button exitProgram;

    @FXML
    private Button modParts;

    @FXML
    private Button modifyProduct;

    @FXML
    private TextField partsSearch;

    @FXML
    private TextField productsSearch;

    public void tableView() {
    }

    @FXML
    void addParts(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddPart.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void addProduct(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddProduct.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void deleteParts() {
        if (tableView.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please select a part in order " +
                    "to delete it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Part selectedPart = tableView.getSelectionModel().getSelectedItem();
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "This will delete the part you " +
                "selected. Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Inventory.deletePart(selectedPart);
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    @FXML
    void deleteProduct() {
        if (tableViewProducts.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please select a product in order " +
                    "to delete it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Product selectedProduct = tableViewProducts.getSelectionModel().getSelectedItem();
        if (! selectedProduct.getAllAssociatedParts().isEmpty()) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "This product has parts associated with it. " +
                    "You must modify this part " +
                   "and delete all of its associated parts before deleting this product.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "This will delete the product you " +
                "selected. Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Inventory.deleteProduct(selectedProduct);
            }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    @FXML
    void exitProgram(ActionEvent event) {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to exit the program?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Platform.exit();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    @FXML
    void modParts() {
        TableView.TableViewSelectionModel<Part> selectedPart = tableView.getSelectionModel();
        if (tableView.getSelectionModel().getSelectedItem() instanceof InHouse) {
            ModifyPartController.passObject((InHouse) selectedPart.getSelectedItem());
        }
        else {
            ModifyPartController.passObject((Outsourced) selectedPart.getSelectedItem());
        }

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyPart.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setTitle("Modify Parts");
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please click on a part to modify it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
            }
        }
    }

    @FXML
    void modifyProduct(ActionEvent event) {
        TableView.TableViewSelectionModel<Product> selectedProduct = tableViewProducts.getSelectionModel();
        ModifyProductController.passObject(selectedProduct.getSelectedItem());

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyProduct.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = new Stage();
            stage.setTitle("Modify Products");
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "Please click on a product to modify it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
            }
        }
    }

    public boolean isNumeric (String name) {
        try {
            Integer.parseInt(name);
        }
        catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public void searchPartNameHandler(ActionEvent ae) {
        if (isNumeric(partsSearch.getText())) {
            ObservableList<Part> desiredID = FXCollections.observableArrayList();
            desiredID.add(Inventory.lookupPart(Integer.parseInt(partsSearch.getText())));
            tableView.setItems(desiredID);
        }
        else {
            tableView.setItems(Inventory.lookupPart(partsSearch.getText()));
        }
    }

    public void searchProductNameHandler(ActionEvent ae) {
        if (isNumeric(productsSearch.getText())) {
            ObservableList<Product> desiredID = FXCollections.observableArrayList();
            desiredID.add(Inventory.lookupProduct(Integer.parseInt(productsSearch.getText())));
            tableViewProducts.setItems(desiredID);
        }
        else {
            tableViewProducts.setItems(Inventory.lookupProduct(productsSearch.getText()));
        }
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableView.setItems(Inventory.getAllParts());
        tableViewProducts.setItems(Inventory.getAllProducts());

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayProductID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayProductName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayProductLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayProductPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}