package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;

import java.net.URL;
import java.util.ResourceBundle;

public class AddProductController implements Initializable {

    @FXML
    private Button Cancel;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addID;

    @FXML
    private Button addInHousePart;

    @FXML
    private TextField addInv;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private TableView<Part> displayAllParts;

    @FXML
    private TableView<Part> displayAssociatedParts;

    @FXML
    private TableColumn<?, ?> displayPartID;

    @FXML
    private TableColumn<?, ?> displayAssocPartID;

    @FXML
    private TableColumn<?, ?> displayPartLevel;

    @FXML
    private TableColumn<?, ?> displayAssocPartLevel;

    @FXML
    private TableColumn<?, ?> displayPartName;

    @FXML
    private TableColumn<?, ?> displayAssocPartName;

    @FXML
    private TableColumn<?, ?> displayPartPrice;

    @FXML
    private TableColumn<?, ?> displayAssocPartPrice;

    @FXML
    private Button removeInHousePart;

    @FXML
    private Button save;

    @FXML
    void Cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void addID(ActionEvent event) {

    }

    @FXML
    void addAssocPart(MouseEvent event) {
        Part selectedPart = displayAllParts.getSelectionModel().getSelectedItem();

        displayAssocPartID.setCellValueFactory
                (new PropertyValueFactory<>(String.valueOf(selectedPart.getId())));
        displayAssocPartName.setCellValueFactory
                (new PropertyValueFactory<>(selectedPart.getName()));
        displayAssocPartLevel.setCellValueFactory
                (new PropertyValueFactory<>(String.valueOf(selectedPart.getStock())));
        displayAssocPartPrice.setCellValueFactory
                (new PropertyValueFactory<>(String.valueOf(selectedPart.getPrice())));

        displayAllParts.getSelectionModel().clearSelection();
    }

    @FXML
    void addInv(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void displayMax(ActionEvent event) {

    }

    @FXML
    void removeInHousePart(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) {
        int stock = Integer.parseInt(addInv.getText());
        int min = Integer.parseInt(addMin.getText());
        int max = Integer.parseInt(addMax.getText());
        String name = addName.getText();
        double price = Double.parseDouble(addPrice.getText());

        displayAssociatedParts.getSelectionModel().getTableView();

        Inventory.addProduct(new Product(Product.randomId(), name, price, stock, min, max));

        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        displayAllParts.setItems(Inventory.getAllParts());

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayAssocPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayAssocPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayAssocPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayAssocPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}
