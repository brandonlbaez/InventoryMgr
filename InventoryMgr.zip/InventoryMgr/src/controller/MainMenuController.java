package controller;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import model.*;

public class MainMenuController implements Initializable {

    @FXML
    private Button addPartsButton;

    @FXML
    private Button addProduct;

    @FXML
    private Button deleteParts;

    @FXML
    private Button deleteProduct;

    @FXML
    private TableView<Parts> tableView;

    @FXML
    private TableView<Products> tableViewProducts;

    @FXML
    private TableColumn<Parts, Integer> displayPartID;

    @FXML
    private TableColumn<Parts, Integer> displayPartLevel;

    @FXML
    private TableColumn<Parts, String> displayPartName;

    @FXML
    private TableColumn<Parts, Double> displayPartPrice;

    @FXML
    private TableColumn<Products, Integer> displayProductID;

    @FXML
    private TableColumn<Products, Integer> displayProductLevel;

    @FXML
    private TableColumn<Products, String> displayProductName;

    @FXML
    private TableColumn<Products, Double> displayProductPrice;

    @FXML
    private Button exitProgram;

    @FXML
    private Button modParts;

    @FXML
    private Button modifyProduct;

    @FXML
    private TextField partsSearch;

    @FXML
    private TextField productsSearch;

    public void tableView(SortEvent<TableView<Parts>> tableViewSortEvent) {
    }

    public void tableViewProducts(SortEvent<TableView<Products>> tableViewSortEvent) {
    }

    @FXML
    void addParts(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddInHouse.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void addProduct(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddProduct.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public boolean deleteParts(int id) {
        for(Parts parts : Inventory.getAllParts()) {
            if(parts.getId() == id) {
                return Inventory.getAllParts().remove(parts);
            }
        }
        return false;
    }

    @FXML
    public boolean deleteProduct(int id) {
        for(Products products : Inventory.getAllProducts()) {
            if(products.getId() == id) {
                return Inventory.getAllProducts().remove(products);
            }
        }
        return false;
    }

    @FXML
    void exitProgram(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    void modParts(ActionEvent event) throws IOException {
        TableView.TableViewSelectionModel<Parts> selectedPart = tableView.getSelectionModel();
        System.out.println(selectedPart);

        ModifyInHouseController.passObject(selectedPart.getSelectedItem());

        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyInHouse.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Modify Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void modifyProduct(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyProduct.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public boolean partsSearch(int id) {
        for(Parts parts : Inventory.getAllParts()) {
            if(parts.getId() == id)
                return true;
        }
        return false;
    }

    @FXML
    public boolean productsSearch(int id) {
        for(Products products: Inventory.getAllProducts()) {
            if(products.getId() == id)
                return true;
        }
        return false;
    }

    public boolean updatePart(int id, Parts parts) {
        int counter = -1;
        for(Parts updatedPart : Inventory.getAllParts()) {
            counter++;
            if(updatedPart.getId() == id) {
                Inventory.getAllParts().set(counter, parts);
            }
        }
        return false;
    }

    public boolean updateProduct(int id, Products products) {
        int counter = -1;
        for(Products updatedProduct : Inventory.getAllProducts()) {
            counter++;
            if(updatedProduct.getId() == id) {
                Inventory.getAllProducts().set(counter, products);
            }
        }
        return false;
    }

    public Parts selectParts(int id) {
        for(Parts parts : Inventory.getAllParts()) {
            if(parts.getId() == id)
                return parts;
        }
        return null;
    }

    public Products selectProducts(int id) {
        for(Products products : Inventory.getAllProducts()) {
            if(products.getId() == id)
                return products;
        }
        return null;
    }

    public ObservableList<Parts> filterParts(String name) {
        if (!Inventory.getFilteredParts().isEmpty())
            Inventory.getFilteredParts().clear();

        for (Parts parts : Inventory.getAllParts()) {
            if (parts.getName().contains(name))
                Inventory.getFilteredParts().add(parts);

        if (Inventory.getFilteredParts().isEmpty())
            return Inventory.getAllParts();
        else
            return Inventory.getFilteredParts();
        }
        return Inventory.getFilteredParts();
    }

    public ObservableList<Parts> filterParts(int id) {
        if (!Inventory.getFilteredParts().isEmpty())
            Inventory.getFilteredParts().clear();

        for (Parts parts : Inventory.getAllParts()) {
            if (parts.getId() == id)
                Inventory.getFilteredParts().add(parts);

        if (Inventory.getFilteredParts().isEmpty())
            return Inventory.getAllParts();
        else
            return Inventory.getFilteredParts();
        }
        return Inventory.getFilteredParts();
    }

    public ObservableList<Products> filterProducts(String name) {
        if (!Inventory.getFilteredProducts().isEmpty())
            Inventory.getFilteredProducts().clear();

        for (Products products : Inventory.getAllProducts()) {
            if (products.getName().contains(name))
                Inventory.getFilteredProducts().add(products);

            if (Inventory.getFilteredProducts().isEmpty())
                return Inventory.getAllProducts();
            else
                return Inventory.getFilteredProducts();
        }
        return Inventory.getFilteredProducts();
    }

    public ObservableList<Products> filterProducts(int id) {
        if (!Inventory.getFilteredProducts().isEmpty())
            Inventory.getFilteredProducts().clear();

        for (Products products : Inventory.getAllProducts()) {
            if (products.getId() == id)
                Inventory.getFilteredProducts().add(products);

            if (Inventory.getFilteredProducts().isEmpty())
                return Inventory.getAllProducts();
            else
                return Inventory.getFilteredProducts();
        }
        return Inventory.getFilteredProducts();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableView.setItems(Inventory.getAllParts());
        tableViewProducts.setItems(Inventory.getAllProducts());

        //tableView.setItems(filterParts(206042));
        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayProductID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayProductName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayProductLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayProductPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        try {
            updatePart(204662, new InHouse(204000, "Nut", 0.005, 225, 0, 1005, 1234));
            System.out.println("Updated");
        }
        catch (Exception e) {
            System.out.println("Not updated");
        }
    }
}