package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.*;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class AddProductController implements Initializable {

    private static Product selectedProduct;

    @FXML
    private Button Cancel;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addID;

    @FXML
    private Button addAssocPart;

    @FXML
    private TextField addStock;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private TableView<Part> displayAllParts;

    @FXML
    private TableView<Part> displayAssociatedParts;

    @FXML
    private TableColumn<Part, Integer> displayPartID;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartID;

    @FXML
    private TableColumn<Part, Integer> displayPartLevel;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartLevel;

    @FXML
    private TableColumn<Part, String> displayPartName;

    @FXML
    private TableColumn<Part, String> displayAssocPartName;

    @FXML
    private TableColumn<Part, Double> displayPartPrice;

    @FXML
    private TableColumn<Part, Double> displayAssocPartPrice;

    @FXML
    private Button removeInHousePart;

    @FXML
    private Button save;

    @FXML
    void Cancel(ActionEvent event) {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to cancel?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) Cancel.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    @FXML
    void addID(ActionEvent event) {

    }

    void makeList () {
        ObservableList<Part> exampleList = FXCollections.observableArrayList();
        exampleList.addAll(selectedProduct.getAllAssociatedParts());
    }

    @FXML
    void addAssocPart(MouseEvent event) {
        if (addAssocPart.isPressed()) {
            Part addedPart = displayAllParts.getSelectionModel().getSelectedItem();
            ObservableList<Part> associatedParts = FXCollections.observableArrayList();
        }
//        if (selectedProduct == null) {
//            Alert alert = new Alert((Alert.AlertType.WARNING), "At least one of your text fields is blank. \n" +
//                    "Please make sure all text fields have a value before associating parts to this " +
//                    "product.");
//            Optional<ButtonType> result = alert.showAndWait();
//            if (result.isPresent() && result.get() == ButtonType.OK) {
//                alert.close();
//            }
//        }
//        ObservableList<Part> associatedParts = FXCollections.observableArrayList();
//        if (addAssocPart.isPressed()) {
//            Part addedPart = displayAllParts.getSelectionModel().getSelectedItem();
//            associatedParts.add(addedPart);
//            displayAssociatedParts.setItems(associatedParts);
//        }
    }

    @FXML
    void addStock(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void addMax(ActionEvent event) {

    }

    @FXML
    void removeAssocPart(ActionEvent event) {
    }

    @FXML
    void save(ActionEvent event) {
        String validStock = addStock.getText();
        String validMin = addMin.getText();
        String validMax = addMax.getText();
        String validName = addName.getText();
        String validPrice = addPrice.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank()) {
            Alert alert = new Alert((Alert.AlertType.WARNING), "At least one of your text fields is blank. \n" +
                    "Please make sure all text fields have a value before pressing save.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(addStock.getText());
            error = "Min";
            int min = Integer.parseInt(addMin.getText());
            error = "Max";
            int max = Integer.parseInt(addMax.getText());
            error = "Name";
            String name = addName.getText();
            error = "Price";
            double price = Double.parseDouble(addPrice.getText());

            if (min > stock || stock > max) {
                Alert alert = new Alert((Alert.AlertType.WARNING), "Error: Min must be less than or equal to the " +
                        "available stock.\n" +
                        "The available stock must be less than or equal to the max.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    return;
                }
            Inventory.addProduct(new Product(Product.randomId(), name, price, stock, min, max));
            }
        }
        catch (IllegalArgumentException e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), error + " is an incorrect value. " +
                    "Stock, min, max and price must contain a number. " +
                    "Name must contain a sequence of letters and/or numbers.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
        }

        int stock = Integer.parseInt(addStock.getText());
        int min = Integer.parseInt(addMin.getText());
        int max = Integer.parseInt(addMax.getText());
        String name = addName.getText();
        double price = Double.parseDouble(addPrice.getText());

        Inventory.addProduct(new Product
                (Product.randomId(), name, price, stock, min, max));

        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        displayAllParts.setItems(Inventory.getAllParts());

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayAssocPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayAssocPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayAssocPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayAssocPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}
