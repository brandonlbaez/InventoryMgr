package model;

/**
 The Part class is an abstract class that is implemented by the InHouse and Outsourced
 classes that inherit from it. Only InHouse or Outsourced parts may be created; a Part
 class cannot be directly made.*/
public abstract class Part {
    private int id, stock, min, max;
    private String name;
    private double price;

    /**
     The Part constructor will create a part and sets the ID, name, price, available stock,
     minimum and maximum values to their values in the constructor.
     @param id The ID of the part.
     @param name The name of the part.
     @param price The price of the part.
     @param stock The stock of the part.
     @param min The lowest possible amount of a part.
     @param max The highest possible amount of a part.*/
    public Part(int id, String name, double price, int stock, int min, int max) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }

    /**
     The getId method returns the ID associated with a part.
     @return Returns the ID of a part.*/
    public int getId() {
        return id;
    }

    /**
     The setId method sets the ID of a part to the integer given in the parameter.
     @param id The ID the part will have after the method is called.*/
    public void setId(int id) {
        this.id = id;
    }

    /**
     The getStock method returns the available stock of a part.
     @return Returns the available stock of a part.*/
    public int getStock() {
        return stock;
    }

    /**
     The setStock method sets the available stock of a part to the integer given in the parameter.
     @param stock The available stock that the part will have after the method is called.*/
    public void setStock(int stock) {
        this.stock = stock;
    }

    /**
     The getMin method returns the minimum amount of a part that can be
     in the inventory.
     @return Returns the lowest possible amount of a part in the inventory.*/
    public int getMin() {
        return min;
    }

    /**
     The setMin method sets the lowest possible amount of a part
     to the integer given in the parameter.
     @param min The lowest amount of stock that the part may have.*/
    public void setMin(int min) {
        this.min = min;
    }

    /**
     The getMax method returns the maximum amount of a part that can be
     in the inventory.
     @return Returns the highest possible amount of a part in the inventory.*/
    public int getMax() {
        return max;
    }

    /**
     The setMax method sets the highest possible amount of a part
     to the integer given in the parameter.
     @param max The highest amount of stock that the part may have.*/
    public void setMax(int max) {
        this.max = max;
    }

    /**
     The getName method returns the name of a part in the inventory.
     @return Returns the name of a part in the inventory.*/
    public String getName() {
        return name;
    }

    /**
     The setName method renames the part to the string given in the parameter.
     @param name The new name of the part.*/
    public void setName(String name) {
        this.name = name;
    }

    /**
     The getPrice method returns the price of a part in the inventory.
     @return Returns the price of a part in the inventory.*/
    public double getPrice() {
        return price;
    }

    /**
     The setPrice method changes the price of a part to the double given in the parameter.
     @param price The new price of the product.*/
    public void setPrice(double price) {
        this.price = price;
    }
}