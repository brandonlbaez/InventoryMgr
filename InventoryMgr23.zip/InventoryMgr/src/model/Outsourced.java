package model;

/**
 The Outsourced class inherits the properties of the Part class and allows
 Outsourced parts to be created.*/
public class Outsourced extends Part {
    private String companyName;

    /**
     The Outsourced constructor will create an Outsourced part that inherits the properties of the Part
     superclass. It will set the companyName given when the constructor is called and assign it to the
     new Outsourced part.
     @param id The ID of the Outsourced part.
     @param name The name of the Outsourced part.
     @param price The price of the Outsourced part.
     @param stock The stock of the Outsourced part.
     @param min The lowest possible amount of an Outsourced part.
     @param max The highest possible amount of an Outsourced part.
     @param companyName The company name of an Outsourced part.*/
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName) {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }

    /**
     The getCompanyName method will return the companyName of an Outsourced part.
     @return returns the companyName of the given part.*/
    public String getCompanyName() {
        return companyName;
    }

    /**
     The setCompanyName method will change the companyName of an Outsourced part to
     the string provided.
     @param companyName The new companyName that the Outsourced part will have.*/
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

}