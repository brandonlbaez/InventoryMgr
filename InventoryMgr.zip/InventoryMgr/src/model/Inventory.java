package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.Objects;
import java.util.Random;

/**
 *
 * @author Brandon
 */
public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    static Random random = new Random();

    public static int partRandomId() {
        int lowerBound = 1000000;
        int upperBound = 9999999;
        return random.nextInt(lowerBound, upperBound);
    }

    public static void addParts(Part parts) {
        allParts.add(parts);
    }

    public static boolean deletePart(Part selectedPart) {
        return allParts.remove(selectedPart);
    }

    public static void updatePart(int id, Part parts) {
        int counter = -1;
        for(Part updatedPart : Inventory.getAllParts()) {
            counter++;
            if(updatedPart.getId() == id) {
                Inventory.getAllParts().set(counter, parts);
            }
        }
    }

    public static void updateProduct(int id, Product products) {
        int counter = -1;
        for(Product updatedProduct : Inventory.getAllProducts()) {
            counter++;
            if(updatedProduct.getId() == id) {
                Inventory.getAllProducts().set(counter, products);
            }
        }
    }

    public static Part lookupPart(int id) {
        for(Part part : Inventory.getAllParts()) {
            if(part.getId() == id)
                return part;
        }
        return null;
    }

    public static ObservableList<Part> lookupPart(String name) {
        ObservableList<Part> desiredParts = FXCollections.observableArrayList();
        for (Part part : Inventory.getAllParts()) {
            if (part.getName().contains(name)) {
                desiredParts.add(part);
            }
        }
        return desiredParts;
    }

    public static Product lookupProduct(int id) {
        for(Product product : Inventory.getAllProducts()) {
            if(product.getId() == id)
                return product;
        }
        return null;
    }
    public static ObservableList<Product> lookupProduct(String name) {
        ObservableList<Product> desiredProducts = FXCollections.observableArrayList();
        for (Product product : Inventory.getAllProducts()) {
            if (product.getName().contains(name)) {
                desiredProducts.add(product);
            }
        }
        return desiredProducts;
    }

    public static void addProduct(Product products) {
        allProducts.add(products);
    }

    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }

    public static ObservableList<Part> getAllParts() {
            return allParts;
    }

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

}
