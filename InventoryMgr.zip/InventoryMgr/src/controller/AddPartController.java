package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;

public class AddPartController {

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;
    @FXML
    private Label dynamicLabel;

    @FXML
    private TextField addStock;

    @FXML
    private TextField addMax;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private Button save;

    @FXML
    private TextField dynamicTextField;

    @FXML
    void SelectInHousePart(ActionEvent event) {
        dynamicLabel.setText("Machine ID");
        AddOutsourcedPart.setSelected(false);
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) {
        dynamicLabel.setText("Company Name");
        AddInHouse.setSelected(false);
    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void addID(ActionEvent event) {

    }

    @FXML
    void addInv(ActionEvent event) {

    }

    @FXML
    void dynamicTextField(ActionEvent event) {

    }

    @FXML
    void addMax(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) {
        String validStock = addStock.getText();
        String validMin = addMin.getText();
        String validMax = addMax.getText();
        String validName = addName.getText();
        String validPrice = addPrice.getText();
        String validDynamicTxtField = dynamicTextField.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank() ||
                validDynamicTxtField.isBlank()
        )
        {
                System.out.println("At least one of your text fields is blank. " +
                        "Please make sure all text fields have a value before pressing save.");
                return;
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(addStock.getText());
            error = "Min";
            int min = Integer.parseInt(addMin.getText());
            error = "Max";
            int max = Integer.parseInt(addMax.getText());
            error = "Name";
            String name = addName.getText();
            error = "Price";
            double price = Double.parseDouble(addPrice.getText());

            if (min > stock || stock > max) {
                System.out.println("Error: Min must be less than or equal to the available stock." +
                        "The available stock must be less than or equal to the max.");
                return;
            }

            if (AddInHouse.isSelected()) {
                int machineID = Integer.parseInt(dynamicTextField.getText());
                Inventory.addParts(new InHouse(Inventory.partRandomId(), name, price, stock, min, max, machineID));
            }
            else {
                String companyName = dynamicTextField.getText();
                Inventory.addParts(new Outsourced(Inventory.partRandomId(), name, price, stock, min, max, companyName));
            }
        }
        catch (IllegalArgumentException e) {
            System.out.println(error + " is an incorrect value. Stock, min, max and price must contain a number. " +
                    "Name must contain a sequence of letters and/or numbers.");
            return;
        }

        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }
}
