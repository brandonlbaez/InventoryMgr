package controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;

public class MainMenuController implements Initializable {
    @FXML
    private Button addPartsButton;

    @FXML
    private Button addProduct;

    @FXML
    private Button deleteParts;

    @FXML
    private Button deleteProduct;

    @FXML
    private TableColumn<?, ?> displayPartID;

    @FXML
    private TableColumn<?, ?> displayPartLevel;

    @FXML
    private TableColumn<?, ?> displayPartName;

    @FXML
    private TableColumn<?, ?> displayPartPrice;

    @FXML
    private TableColumn<?, ?> displayProductID;

    @FXML
    private TableColumn<?, ?> displayProductLevel;

    @FXML
    private TableColumn<?, ?> displayProductName;

    @FXML
    private TableColumn<?, ?> displayProductPrice;

    @FXML
    private Button exitProgram;

    @FXML
    private Button modParts;

    @FXML
    private Button modifyProduct;

    @FXML
    private TextField partsSearch;

    @FXML
    private TextField productsSearch;

    @FXML
    void addParts(ActionEvent event) {

    }

    @FXML
    void addProduct(ActionEvent event) {

    }

    @FXML
    void deleteParts(ActionEvent event) {

    }

    @FXML
    void deleteProduct(ActionEvent event) {

    }

    @FXML
    void exitProgram(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    void modParts(ActionEvent event) {

    }

    @FXML
    void modifyProduct(ActionEvent event) {

    }

    @FXML
    void partsSearch(ActionEvent event) {

    }

    @FXML
    void productsSearch(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}