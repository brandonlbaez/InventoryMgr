package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.Random;

/**
 The Inventory class holds a list of all parts and all products in the inventory.
 The java.util.Random class is imported, and a static Random variable is created
 so IDs for parts and products are randomly generated 7-digit numbers.*/
public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    static Random random = new Random();

    /**
     The randomId method randomly generates a 7-digit ID for any part created.*/
    public static int partRandomId() {
        int lowerBound = 1000000;
        int upperBound = 9999999;
        return random.nextInt(lowerBound, upperBound);
    }

    /**
     The randomId method randomly generates a 7-digit ID for any product created.*/
    public static int productRandomId() {
        int lowerBound = 1000000;
        int upperBound = 9999999;
        return random.nextInt(lowerBound, upperBound);
    }

    /**
     The addPart method adds a part to the inventory's ObservableList of parts.*/
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    /**
     The deletePart method removes a part from the inventory's ObservableList of parts.*/
    public static boolean deletePart(Part selectedPart) {
        return allParts.remove(selectedPart);
    }

    /**
     The updatePart method takes the index where the part is located in the allParts
     ObservableList and a part as parameters. It increments the counter variable for
     each part in the allParts ObservableList until the oldPart matches the ID
     given in the parameter. If this occurs, the matching part will be changed at the
     matching index to contain newPart instead of oldPart.
     @param index The ID of the part.
     @param newPart The part that will take the place of the old part in the ObservableList.*/
    public static void updatePart(int index, Part newPart) {
        int counter = -1;
        for(Part oldPart : Inventory.getAllParts()) {
            counter++;
            if(oldPart.getId() == index) {
                Inventory.getAllParts().set(counter, newPart);
            }
        }
    }

    /**
     The updateProduct method takes the index where the product is located in the
     allProducts ObservableList and a product as parameters. It increments the counter
     variable for each product in the allProducts ObservableList until the updatedProduct
     matches the ID given in the parameter. If this occurs, the matching product will be
     changed at the matching index to contain newProduct instead of oldProduct.
     @param index The ID of the product.
     @param newProduct The product that will take the place of the old product
     in the ObservableList.*/
    public static void updateProduct(int index, Product newProduct) {
        int counter = -1;
        for(Product oldProduct : Inventory.getAllProducts()) {
            counter++;
            if(oldProduct.getId() == index) {
                Inventory.getAllProducts().set(counter, newProduct);
            }
        }
    }

    /**
     The lookupPart method accepts an ID as a parameter and returns the exact
     match of the part which ID matches the parameter.
     @param partId The ID that is being searched for.
     @return Returns either the matching part or a false boolean value,
     meaning no matching part was found.*/
    public static Part lookupPart(int partId) {
        for(Part part : Inventory.getAllParts()) {
            if(part.getId() == partId)
                return part;
        }
        return null;
    }

    /**
     The lookupPart method accepts a partName as a parameter and returns any parts
     that contain the string provided in the parameter.
     @param partName The string of characters that is being searched for.
     @return Returns any parts that match the string in the parameter.*/
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> desiredParts = FXCollections.observableArrayList();
        for (Part part : Inventory.getAllParts()) {
            if (part.getName().contains(partName)) {
                desiredParts.add(part);
            }
        }
        return desiredParts;
    }

    /**
     The lookupProduct method accepts an ID as a parameter and returns the exact
     match of the product which ID matches the parameter.
     @param productId The ID that is being searched for.
     @return Returns either the matching product or a false boolean value,
     meaning no matching product was found.*/
    public static Product lookupProduct(int productId) {
        for(Product product : Inventory.getAllProducts()) {
            if(product.getId() == productId)
                return product;
        }
        return null;
    }
    /**
     The lookupProduct method accepts a productName as a parameter and returns any
     products that contain the string provided in the parameter.
     @param productName The string of characters that is being searched for.
     @return Returns any products that match the string in the parameter.*/
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> desiredProducts = FXCollections.observableArrayList();
        for (Product product : Inventory.getAllProducts()) {
            if (product.getName().contains(productName)) {
                desiredProducts.add(product);
            }
        }
        return desiredProducts;
    }

    /**
     The addProduct method takes a product as a parameter and adds it to the
     inventory's ObservableList of all products in the inventory.
     @param newProduct The product to be added to the allProducts ObservableList.*/
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    /**
     The removeProduct method takes a product as a parameter and removes it
     from the inventory's ObservableList of all products in the inventory.
     @param selectedProduct The product to be removed from the allProducts ObservableList.
     @return Returns the list without the selectedProduct in the parameter.*/
    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }

    /**
     The getAllParts method returns an ObservableList of all parts in the inventory.*/
    public static ObservableList<Part> getAllParts() {
            return allParts;
    }

    /**
     The getAllProducts method returns an ObservableList of all products in the inventory.*/
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }
}