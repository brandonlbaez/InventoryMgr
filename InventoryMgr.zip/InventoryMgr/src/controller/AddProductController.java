package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddProductController {

    @FXML
    private Button Cancel;

    @FXML
    private TextField DisplayMax;

    @FXML
    private TextField addID;

    @FXML
    private Button addInHousePart;

    @FXML
    private TextField addInv;

    @FXML
    private TextField addMin;

    @FXML
    private TextField addName;

    @FXML
    private TextField addPrice;

    @FXML
    private TableColumn<?, ?> displayPartID;

    @FXML
    private TableColumn<?, ?> displayPartID1;

    @FXML
    private TableColumn<?, ?> displayPartLevel;

    @FXML
    private TableColumn<?, ?> displayPartLevel1;

    @FXML
    private TableColumn<?, ?> displayPartName;

    @FXML
    private TableColumn<?, ?> displayPartName1;

    @FXML
    private TableColumn<?, ?> displayPartPrice;

    @FXML
    private TableColumn<?, ?> displayPartPrice1;

    @FXML
    private Button removeInHousePart;

    @FXML
    private Button saveInHouse;

    @FXML
    void Cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void addID(ActionEvent event) {

    }

    @FXML
    void addInHousePart(ActionEvent event) {

    }

    @FXML
    void addInv(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void displayMax(ActionEvent event) {

    }

    @FXML
    void removeInHousePart(ActionEvent event) {

    }

    @FXML
    void saveInHouse(ActionEvent event) {

    }

}
