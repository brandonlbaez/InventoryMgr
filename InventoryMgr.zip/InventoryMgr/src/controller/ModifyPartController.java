package controller;

import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Part;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
public class ModifyPartController implements Initializable {

    private static Part selectedPart;

    @FXML
    private RadioButton modifyInHouse;

    @FXML
    private RadioButton modifyOutsourced;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyID;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private Button Save;

    @FXML
    private TextField modifyDynTxtField;

    @FXML
    private ToggleGroup toggleGroup1;

    @FXML
    void SelectInHousePart(ActionEvent event) {
        ;
    }

    static void passObject(InHouse part){
        selectedPart = part;
    }

    static void passObject(Outsourced part){
        selectedPart = part;
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) throws IOException {

    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void modifyID(ActionEvent event) {

    }

    @FXML
    void modifyInv(ActionEvent event) {

    }

    @FXML
    void modifyMachineID(ActionEvent event) {

    }

    @FXML
    void modifyMax(ActionEvent event) {

    }

    @FXML
    void modifyMin(ActionEvent event) {

    }

    @FXML
    void modifyName(ActionEvent event) {

    }

    @FXML
    void modifyPrice(ActionEvent event) {

    }

    @FXML
    void save() {
        int stock = Integer.parseInt(modifyInv.getText());
        int min = Integer.parseInt(modifyMin.getText());
        int max = Integer.parseInt(modifyMax.getText());
        String name = modifyName.getText();
        double price = Double.parseDouble(modifyPrice.getText());

        if (selectedPart instanceof InHouse) {
            int machineID = Integer.parseInt(modifyDynTxtField.getText());
            Inventory.updatePart(selectedPart.getId(),
                    new InHouse(selectedPart.getId(), name, price, stock, min, max, machineID));
        }
        else {
            String companyName = modifyDynTxtField.getText();
            Inventory.updatePart(selectedPart.getId(),
                    new Outsourced(selectedPart.getId(), name, price, stock, min, max, companyName));
        }

        Stage stage = (Stage) Save.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modifyID.setText(String.valueOf(selectedPart.getId()));
        modifyInv.setText(String.valueOf(selectedPart.getStock()));
        modifyName.setText(selectedPart.getName());
        modifyPrice.setText(String.valueOf(selectedPart.getPrice()));
        modifyMin.setText(String.valueOf(selectedPart.getMin()));
        modifyMax.setText(String.valueOf(selectedPart.getMax()));
        if (selectedPart instanceof InHouse) {
            modifyDynTxtField.setText(String.valueOf(((InHouse) selectedPart).getMachineID()));
            modifyOutsourced.setDisable(true);
        }
        else {
            modifyDynTxtField.setText(((Outsourced) selectedPart).getCompanyName());
            modifyInHouse.setDisable(true);
        }
    }
}
