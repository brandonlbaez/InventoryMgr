package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Parts;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
public class ModifyInHouseController {

    private static Parts selectedPart;

    @FXML
    private RadioButton AddInHouse;

    @FXML
    private RadioButton AddOutsourcedPart;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyID;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private Button Save;

    @FXML
    private TextField modifyMachineID;

    @FXML
    private ToggleGroup toggleGroup1;

    @FXML
    void SelectInHousePart(ActionEvent event) {
        ;
    }

    static Parts passObject(Parts part){
        selectedPart = part;
        System.out.println(part);
        return part;
    }

    @FXML
    void SelectOutsourcedPart(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/view/ModifyOutsourced.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void cancel(ActionEvent event) {
        Stage stage = (Stage) Cancel.getScene().getWindow();
        stage.close();
    }

    @FXML
    void modifyID(ActionEvent event) {

    }

    @FXML
    void modifyInv(ActionEvent event) {

    }

    @FXML
    void modifyMachineID(ActionEvent event) {

    }

    @FXML
    void modifyMax(ActionEvent event) {

    }

    @FXML
    void modifyMin(ActionEvent event) {

    }

    @FXML
    void modifyName(ActionEvent event) {

    }

    @FXML
    void modifyPrice(ActionEvent event) {

    }

    @FXML
    void save(ActionEvent event) {

    }

    //@Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modifyID.setText(String.valueOf(selectedPart.getId()));
    }

}
