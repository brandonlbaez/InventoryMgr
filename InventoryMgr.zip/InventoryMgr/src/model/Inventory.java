package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.Random;

/**
 *
 * @author Brandon
 */
public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
//    private static ObservableList<Parts> filterParts = FXCollections.observableArrayList();

    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

//    private static ObservableList<Products> filterProducts = FXCollections.observableArrayList();
    static Random random = new Random();

    public static int partRandomId() {
        int lowerBound = 1000000;
        int upperBound = 9999999;
        return random.nextInt(lowerBound, upperBound);
    }

    public static void addParts(Part parts) {
        allParts.add(parts);
    }

    public static boolean deleteParts(Part selectedPart) {
        return allParts.remove(selectedPart);
    }

    public static void updatePart(int id, Part parts) {
        int counter = -1;
        for(Part updatedPart : Inventory.getAllParts()) {
            counter++;
            if(updatedPart.getId() == id) {
                Inventory.getAllParts().set(counter, parts);
            }
        }
    }

    public static void updateProduct(int id, Product products) {
        int counter = -1;
        for(Product updatedProduct : Inventory.getAllProducts()) {
            counter++;
            if(updatedProduct.getId() == id) {
                Inventory.getAllProducts().set(counter, products);
            }
        }
    }

    public Part lookupPart(int id) {
        for(Part parts : Inventory.getAllParts()) {
            if(parts.getId() == id)
                return parts;
        }
        return null;
    }

    public Product lookupProduct(int id) {
        for(Product products : Inventory.getAllProducts()) {
            if(products.getId() == id)
                return products;
        }
        return null;
    }

    public static void addProduct(Product products) {
        allProducts.add(products);
    }

    public static boolean deleteProduct(Product selectedProduct) {
        return allProducts.remove(selectedProduct);
    }

    public static ObservableList<Part> getAllParts() {
            return allParts;
    }

//    public static ObservableList<Parts> getFilteredParts() {
//        return filterParts;
//    }

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

//    public static ObservableList<Products> getFilteredProducts() {
//        return filterProducts;
//    }
}
