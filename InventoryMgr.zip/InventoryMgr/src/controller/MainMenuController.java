package controller;

import javafx.application.Platform;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.Outsourced;
import model.Parts;

public class MainMenuController implements Initializable {

    @FXML
    private Button addPartsButton;

    @FXML
    private Button addProduct;

    @FXML
    private Button deleteParts;

    @FXML
    private Button deleteProduct;

    @FXML
    private TableView<Parts> tableView;

    @FXML
    private TableColumn<Parts, Integer> displayPartID;

    @FXML
    private TableColumn<Parts, Integer> displayPartLevel;

    @FXML
    private TableColumn<Parts, String> displayPartName;

    @FXML
    private TableColumn<Parts, Double> displayPartPrice;

    @FXML
    private TableColumn<?, ?> displayProductID;

    @FXML
    private TableColumn<?, ?> displayProductLevel;

    @FXML
    private TableColumn<?, ?> displayProductName;

    @FXML
    private TableColumn<?, ?> displayProductPrice;

    @FXML
    private Button exitProgram;

    @FXML
    private Button modParts;

    @FXML
    private Button modifyProduct;

    @FXML
    private TextField partsSearch;

    @FXML
    private TextField productsSearch;

    public void tableView(SortEvent<TableView<Parts>> tableViewSortEvent) {
    }

    @FXML
    void addParts(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddInHouse.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void addProduct(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/AddProduct.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public boolean deleteParts(int id) {
        for(Parts parts : Inventory.getAllParts()) {
            if(parts.getId() == id) {
                return Inventory.getAllParts().remove(parts);
            }
        }
        return false;
    }

    @FXML
    void deleteProduct(ActionEvent event) {

    }

    @FXML
    void exitProgram(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    void modParts(ActionEvent event) throws IOException {
        TableView.TableViewSelectionModel<Parts> selectedPart = tableView.getSelectionModel();
        System.out.println(selectedPart);

        ModifyInHouseController.passObject(selectedPart.getSelectedItem());

        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyInHouse.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Modify Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void modifyProduct(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/ModifyProduct.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Add Parts");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public boolean partsSearch(int id) {
        for(Parts parts : Inventory.getAllParts()) {
            if(parts.getId() == id)
                return true;
        }
        return false;
    }

    @FXML
    void productsSearch(ActionEvent event) {

    }

    public boolean updatePart(int id, Parts parts) {
        int counter = -1;
        for(Parts InHouse : Inventory.getAllParts()) {
            counter++;
            if(InHouse.getId() == id) {
                Inventory.getAllParts().set(counter, parts);
            }
        }
        return false;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableView.setItems(Inventory.getAllParts());
        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        if(partsSearch(206042))
            System.out.println("Found");
        else
            System.out.println("Not found");

        if(updatePart(204662, new InHouse(204040, "Nut", 0.005, 225, 0, 1005, 91124)))
            System.out.println("Updated");
        else
            System.out.println("Not updated");

        if(deleteParts(604042))
            System.out.println("Deleted");
        else
            System.out.println("Not deleted");
    }
}