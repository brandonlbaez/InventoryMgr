package controller;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import java.util.Optional;

/**
 The Dialog class stores a series of dialog boxes that are used throughout the program
 to alert the user of any exceptions that may occur during use.*/
public class Dialog {
    /**
     The resetScreen method alerts the user when an invalid request has occurred, and
     closes itself when OK is pressed.
     @param name The error message that is displayed in the dialog box.*/
    public static void resetScreen (String name) {
        Alert alert = new Alert((Alert.AlertType.WARNING), name);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            alert.close();
        }
    }

    /**
     The confirmClose method alerts the user when they try to close a menu or the program
     itself, and asks the user to confirm their choice. If OK is clicked, the window or
     program will be closed depending on where this method is called. If cancel is pressed,
     the dialog box will close and the user can proceed normally.*/
    public static void confirmClose (Button button) {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION),
                "Are you sure you want to exit?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) button.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }
}
