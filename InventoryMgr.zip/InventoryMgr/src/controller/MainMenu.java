package controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import model.*;

import java.io.IOException;

public class MainMenu extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader =
                new FXMLLoader(MainMenu.class.getResource("/view/MainMenu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Inventory Manager");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        InHouse examplePart =
                new InHouse(Inventory.partRandomId(),
                        "Transistor", 0.02,
                        5,
                        0,
                        100000,
                        68868);

        InHouse examplePart2 =
                new InHouse(Inventory.partRandomId(),
                        "Bolt",
                        0.01,
                        5000,
                        0,
                        10000,
                        68898);

        InHouse examplePart3 =
                new InHouse(Inventory.partRandomId(),
                        "Wrench", 8.00,
                        10,
                        0,
                        100,
                        86808);

        Outsourced examplePart4 =
                new Outsourced(Inventory.partRandomId(),
                        "Table",
                        150.00,
                        2,
                        0,
                        10,
                        "HP");

        Outsourced examplePart5 =
                new Outsourced(Inventory.partRandomId(),
                        "Hard Drive",
                        100.00,
                        50,
                        0,
                        1000,
                        "Lenovo");

        Product exampleProduct =
                new Product(Product.randomId(),
                        "Computer",
                        2000.00,
                        5,
                        0,
                        10);

        Product exampleProduct2 =
                new Product(Product.randomId(),
                        "Tool Set",
                        100.00,
                        2,
                        0,
                        10);

        Product exampleProduct3 =
                new Product(Product.randomId(),
                        "AirPods",
                        90.00,
                        1,
                        0,
                        5);

        Product exampleProduct4 =
                new Product(Product.randomId(),
                        "AirPods Pro",
                        190.00,
                        1,
                        0,
                        3);

        exampleProduct.addAssociatedPart(examplePart5);
        exampleProduct.addAssociatedPart(examplePart);
        exampleProduct2.addAssociatedPart(examplePart2);
        exampleProduct2.addAssociatedPart(examplePart3);
        exampleProduct3.addAssociatedPart(examplePart4);

        Inventory.addParts(examplePart);
        Inventory.addParts(examplePart2);
        Inventory.addParts(examplePart3);
        Inventory.addParts(examplePart4);
        Inventory.addParts(examplePart5);
        Inventory.addProduct(exampleProduct);
        Inventory.addProduct(exampleProduct2);
        Inventory.addProduct(exampleProduct3);
        Inventory.addProduct(exampleProduct4);

        launch();
    }
}


