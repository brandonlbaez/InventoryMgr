package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Brandon
 */
public class Inventory {
    private static ObservableList<Parts> allParts = FXCollections.observableArrayList();

    public static void addParts(Parts parts) {
        allParts.add(parts);
    }

    public static ObservableList<Parts> getAllParts() {
            return allParts;
    }
}
