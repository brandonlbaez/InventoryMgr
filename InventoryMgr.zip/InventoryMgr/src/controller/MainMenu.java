package controller;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import model.*;

import java.io.IOException;

public class MainMenu extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainMenu.class.getResource("/view/MainMenu.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Inventory Manager");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        InHouse examplePart = new InHouse(204042, "Transistor", 0.02, 5, 0, 100000, 68868);
        InHouse examplePart2 = new InHouse(204662, "Bolt", 0.01, 5000, 0, 10000, 68898);
        InHouse examplePart3 = new InHouse(206042, "Wrench", 8.00, 10, 0, 100, 86808);
        Outsourced examplePart4 = new Outsourced(264042, "Table", 150.00, 2, 0, 10, "HP");
        Outsourced examplePart5 = new Outsourced(604042, "Hard Drive", 100.00, 50, 0, 1000, "Lenovo");

        Products exampleProduct = new Products(12345, "Computer", 2000.00, 5, 0, 10);
        Products exampleProduct2 = new Products(12341, "Tool Set", 100.00, 2, 0, 10);
        Products exampleProduct3 = new Products(12340, "AirPods", 90.00, 1, 0, 5);

        exampleProduct.addAssociatedPart(examplePart5);
        exampleProduct.addAssociatedPart(examplePart);
        exampleProduct2.addAssociatedPart(examplePart2);
        exampleProduct2.addAssociatedPart(examplePart3);
        exampleProduct3.addAssociatedPart(examplePart4);

        Inventory.addParts(examplePart);
        Inventory.addParts(examplePart2);
        Inventory.addParts(examplePart3);
        Inventory.addParts(examplePart4);
        Inventory.addParts(examplePart5);
        Inventory.addProduct(exampleProduct);
        Inventory.addProduct(exampleProduct2);
        Inventory.addProduct(exampleProduct3);

        exampleProduct.deleteAssociatedPart(examplePart);
        //exampleProduct.deleteAssociatedPart(examplePart);

        System.out.printf("The associated part is %s\n", exampleProduct.getAllAssociatedParts());
        //System.out.printf("The associated part is %s\n", exampleProduct.getAllAssociatedParts());
//        System.out.printf("The associated part is %s\n", exampleProduct2.getAllAssociatedParts());
//        System.out.printf("The associated part is %s\n", exampleProduct3.getAllAssociatedParts());
        launch();
    }
}


