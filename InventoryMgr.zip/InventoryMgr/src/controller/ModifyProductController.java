package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Inventory;
import model.Part;
import model.Product;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 The ModifyProductController method has all functions associated with the
 ModifyProduct.fxml file. Initializable is implemented to allow for .fxml
 entities to be interacted with.*/
public class ModifyProductController implements Initializable {

    /**
     The private static selectedProduct is used whenever a product needs to be modified or
     transferred to another controller for use elsewhere in the program.*/
    private static Product selectedProduct;

    @FXML
    private TextField partsSearch;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyID;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private TableView<Part> displayAllParts;

    @FXML
    private TableView<Part> displayAssociatedParts;

    @FXML
    private TableColumn<Part, Integer> displayPartID;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartID;

    @FXML
    private TableColumn<Part, Integer> displayPartLevel;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartLevel;

    @FXML
    private TableColumn<Part, String> displayPartName;

    @FXML
    private TableColumn<Part, String> displayAssocPartName;

    @FXML
    private TableColumn<Part, Double> displayPartPrice;

    @FXML
    private TableColumn<Part, Double> displayAssocPartPrice;

    @FXML
    private Button save;

    /**
     The partsSearch method will use the isNumeric function to see if the string typed in the
     partsSearch text field can be parsed as an integer. If isNumeric returns a true value, it will create a new
     ObservableList called desiredID, call the lookupPart method for that specific integer, and will set the
     items in the table to show a part matching the ID typed in the text field. If isNumeric returns a false
     value, it will call the lookupPart method for the given string, and have the table show all parts
     containing the string typed in the text field. The method will also prompt the user if a matching
     ID or name was not found, and will reset the partsSearch text field and displayAllParts table view.*/
    @FXML
    void partsSearch() {
        if (MainMenuController.isNumeric(partsSearch.getText())) {
            ObservableList<Part> desiredID = FXCollections.observableArrayList();
            Part searchPart = Inventory.lookupPart(Integer.parseInt(partsSearch.getText()));
            desiredID.add(searchPart);
            if (desiredID.contains(null)) {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "A matching ID or name was not found.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    displayAllParts.setItems(Inventory.getAllParts());
                    partsSearch.clear();
                }
            }
            else {
                displayAllParts.setItems(desiredID);
            }
        }
        else if (!MainMenuController.isNumeric(partsSearch.getText())) {
            if (!Inventory.lookupPart(partsSearch.getText()).isEmpty()) {
                displayAllParts.setItems(Inventory.lookupPart(partsSearch.getText()));
            }
            else {
                Alert alert = new Alert((Alert.AlertType.WARNING),
                        "A matching ID or name was not found.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    displayAllParts.setItems(Inventory.getAllParts());
                    partsSearch.clear();
                }
            }
        }
    }

    /**
     The Cancel method prompts the user if they are sure that want to stop modifying a product.
     The program will close the ModifyProduct.fxml file if OK is selected and close the alert window
     if Cancel is selected.*/
    @FXML
    void Cancel() {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to cancel?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) Cancel.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    /**
     The addAssocPart method will check to see if the selectedProduct already contains
     the part the user is trying to add. If this is the case, the program will alert the user
     and state that the selectedPart the user clicked on is already associated with the
     selectedProduct. It will also alert the user if they try to add a product without selecting
     a product from the displayAllParts table first. Otherwise, the method will add the part
     to the selectedProduct's ObservableList of associated parts and display the new set of
     associated parts for the selectedProduct.*/
    @FXML
    void addAssocPart() {
        Part selectedPart = displayAllParts.getSelectionModel().getSelectedItem();
        if (selectedProduct.getAllAssociatedParts().contains(selectedPart)) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    "This part is already associated with the \nproduct you are creating.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        if (displayAllParts.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    "Please select a part in order to add it \nto the list of associated parts.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        selectedProduct.addAssociatedPart(selectedPart);
        displayAssociatedParts.setItems(selectedProduct.getAllAssociatedParts());
    }

    /**
     The removeAssocPart method will check to see if they try to remove a product without selecting
     a product from the displayAssociatedParts table first, and prevent them from doing so.
     Otherwise, the method will remove the part from the selectedProduct's ObservableList of
     associated parts and display the new set of associated parts for the selectedProduct.*/
    @FXML
    void removeAssocPart() {
        if (displayAssociatedParts.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert((Alert.AlertType.WARNING),
                    "This product does not have any parts associated with it.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Part selectedPart = displayAssociatedParts.getSelectionModel().getSelectedItem();
        selectedProduct.deleteAssociatedPart(selectedPart);
        displayAssociatedParts.setItems(selectedProduct.getAllAssociatedParts());
    }

    /**
     The passObject method allows the product selected in the MainMenuController to be
     displayed in the ModifyProductController.*/
    static void passObject(Product products){
        selectedProduct = products;
    }

    /**
     The save method will check to see if any of the text fields are blank and prompt the user
     to make sure all text fields have a value before pressing save. The method will then
     try to parse the values in the text fields. If the min is not less than or equal to
     the available stock, or the available stock is not less than or equal to the max,
     it will prompt the user to make sure this rule is followed. If any of the text fields have
     an incorrect value, the user will be prompted to make sure that name contains a string
     value and that stock, min, max, and price contain a numeric value. If no exceptions occur,
     the program will update the product to have the same randomly generated ID that it had before
     it was edited, but change the product to include the changes the user made, along with any
     new associated parts located in the displayAssociatedParts table. The window will then
     close when this is completed.*/
    @FXML
    void save() {
        String validStock = modifyInv.getText();
        String validMin = modifyMin.getText();
        String validMax = modifyMax.getText();
        String validName = modifyName.getText();
        String validPrice = modifyPrice.getText();

        if (String.valueOf(validStock).isBlank() ||
                String.valueOf(validMin).isBlank() ||
                String.valueOf(validMax).isBlank() ||
                validName.isBlank() ||
                String.valueOf(validPrice).isBlank()
        )
        {
            Alert alert = new Alert((Alert.AlertType.WARNING), "At least one of your text fields is blank.\n" +
                    "Please make sure all text fields have a valid value.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }

        String error = "";
        try {
            error = "Stock";
            int stock = Integer.parseInt(modifyInv.getText());
            error = "Min";
            int min = Integer.parseInt(modifyMin.getText());
            error = "Max";
            int max = Integer.parseInt(modifyMax.getText());
            error = "Name";
            String name = modifyName.getText();
            error = "Price";
            double price = Double.parseDouble(modifyPrice.getText());

            if (min > stock || stock > max) {
                Alert alert = new Alert((Alert.AlertType.WARNING), "Min must be less than or equal to " +
                        "stock.\nThe stock must be less than or equal to the max.");
                Optional<ButtonType> result = alert.showAndWait();
                if (result.isPresent() && result.get() == ButtonType.OK) {
                    alert.close();
                    return;
                }
            }
            for (Part parts : displayAssociatedParts.getSelectionModel().getSelectedItems()) {
                if (! selectedProduct.getAllAssociatedParts().contains(parts)) {
                    selectedProduct.addAssociatedPart(parts);
                }
            Inventory.updateProduct(selectedProduct.getId(),
                new Product(selectedProduct.getId(), name, price, stock, min, max));
                }
            }
        catch (IllegalArgumentException e) {
            Alert alert = new Alert((Alert.AlertType.WARNING), error + " is an invalid value.");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == ButtonType.OK) {
                alert.close();
                return;
            }
        }
        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
    }

    /**
     The initialize method will set the displayAllParts table to display all parts in the
     inventory and set the displayAssociatedProducts table to display all the parts associated
     with the product the user selected. Any information about the selectedProduct will be displayed
     in the text fields. The cells in the table will be set up to display the ID, name, available
     stock and price of all parts and any parts associated with the selectedProduct, respectively.
     @param url The location of the .fxml file.
     @param resourceBundle Resources used that pertain to the user's locale.*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        displayAllParts.setItems(Inventory.getAllParts());
        displayAssociatedParts.setItems(selectedProduct.getAllAssociatedParts());

        modifyID.setText(String.valueOf(selectedProduct.getId()));
        modifyInv.setText(String.valueOf(selectedProduct.getStock()));
        modifyName.setText(selectedProduct.getName());
        modifyPrice.setText(String.valueOf(selectedProduct.getPrice()));
        modifyMin.setText(String.valueOf(selectedProduct.getMin()));
        modifyMax.setText(String.valueOf(selectedProduct.getMax()));

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayAssocPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayAssocPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayAssocPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayAssocPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}