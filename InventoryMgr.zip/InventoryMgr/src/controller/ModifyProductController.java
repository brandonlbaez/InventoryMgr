package controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.fxml.Initializable;
import model.Inventory;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import model.Part;
import model.Product;

public class ModifyProductController implements Initializable {

    private static Product selectedProduct;

    @FXML
    private Button Cancel;

    @FXML
    private TextField modifyMax;

    @FXML
    private TextField modifyID;

    @FXML
    private Button addAssocPart;

    @FXML
    private TextField modifyInv;

    @FXML
    private TextField modifyMin;

    @FXML
    private TextField modifyName;

    @FXML
    private TextField modifyPrice;

    @FXML
    private TableView<Part> displayAllParts;

    @FXML
    private TableView<Part> displayAssociatedParts;

    @FXML
    private TableColumn<Part, Integer> displayPartID;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartID;

    @FXML
    private TableColumn<Part, Integer> displayPartLevel;

    @FXML
    private TableColumn<Part, Integer> displayAssocPartLevel;

    @FXML
    private TableColumn<Part, String> displayPartName;

    @FXML
    private TableColumn<Part, String> displayAssocPartName;

    @FXML
    private TableColumn<Part, Double> displayPartPrice;

    @FXML
    private TableColumn<Part, Double> displayAssocPartPrice;

    @FXML
    private Button removeAssocPart;

    @FXML
    private Button save;

    @FXML
    void Cancel(ActionEvent event) {
        Alert alert = new Alert((Alert.AlertType.CONFIRMATION), "Are you sure you want to cancel?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            Stage stage = (Stage) Cancel.getScene().getWindow();
            stage.close();
        }
        if (result.isPresent() && result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    @FXML
    void addID(ActionEvent event) {

    }

    @FXML
    void addAssocPart(ActionEvent event) {

    }

    @FXML
    void addInv(ActionEvent event) {

    }

    @FXML
    void addMin(ActionEvent event) {

    }

    @FXML
    void addName(ActionEvent event) {

    }

    @FXML
    void addPrice(ActionEvent event) {

    }

    @FXML
    void displayMax(ActionEvent event) {

    }

    @FXML
    boolean removeAssociatedPart(MouseEvent event) {
        passObject(selectedProduct);
        Part selectedPart = displayAssociatedParts.getSelectionModel().getSelectedItem();
        return selectedProduct.deleteAssociatedPart(selectedPart);
    }

    static void passObject(Product products){
        selectedProduct = products;
    }

    @FXML
    void save(ActionEvent event) {

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        displayAllParts.setItems(Inventory.getAllParts());
        displayAssociatedParts.setItems(selectedProduct.getAllAssociatedParts());

        modifyID.setText(String.valueOf(selectedProduct.getId()));
        modifyInv.setText(String.valueOf(selectedProduct.getStock()));
        modifyName.setText(selectedProduct.getName());
        modifyPrice.setText(String.valueOf(selectedProduct.getPrice()));
        modifyMin.setText(String.valueOf(selectedProduct.getMin()));
        modifyMax.setText(String.valueOf(selectedProduct.getMax()));

        displayPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));

        displayAssocPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        displayAssocPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        displayAssocPartLevel.setCellValueFactory(new PropertyValueFactory<>("stock"));
        displayAssocPartPrice.setCellValueFactory(new PropertyValueFactory<>("Price"));
    }
}
