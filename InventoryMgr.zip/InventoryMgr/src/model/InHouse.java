package model;

/**
 The InHouse class inherits the properties of the Part class and allows
 InHouse parts to be created.*/
public class InHouse extends Part {
    private int machineID;

    /**
     The InHouse constructor will create an InHouse part that inherits the properties of the Part
     superclass. It will set the machineID given when the constructor is called and assign it to the
     new InHouse part.
     @param id The ID of the InHouse part.
     @param name The name of the InHouse part.
     @param price The price of the InHouse part.
     @param stock The stock of the InHouse part.
     @param min The lowest possible amount of an InHouse part.
     @param max The highest possible amount of an InHouse part.
     @param machineID The machine ID of an InHouse part.*/
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineID) {
        super(id, name, price, stock, min, max);
        this.machineID = machineID;
    }

    /**
     The getMachineID method will return the machineID of an InHouse part.
     @return returns the machineID of the given product.*/
    public int getMachineID() {
        return machineID;
    }

    /**
     The setMachineID method will change the machineID of an InHouse part to
     the integer provided.
     @param machineID the machineID that the part will have after calling this method.*/
    public void setMachineID(int machineID) {
        this.machineID = machineID;
    }
}